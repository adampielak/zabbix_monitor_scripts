#!/usr/bin/python
# -*- coding: UTF-8 -*-

#===============================================================================
# 导入smtplib和MIMEText
#===============================================================================
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
import sys,os

#===============================================================================
# 收件人
#===============================================================================
#mailto_list=["xxxxxx111@starcor.cn","xxxx222@starcor.cn","xxxx3@starcor.cn"]
#mailto_list=["ruihua.wang@starcor.cn"]
mailto_list=["ruihua.wang@starcor.cn","peng.ye@starcor.cn","liming.zhao@starcor.cn","qian.zhang@starcor.cn"]

#===============================================================================
# 设置服务器，用户名、口令以及邮箱的后缀
#===============================================================================
mail_host="smtp.exmail.qq.com"
mail_port=465
mail_user="starcor_bug@starcor.cn"
mail_pass="Sopms2013"
mail_postfix="starcor.cn"

#===============================================================================
# 发送邮件
#===============================================================================
def getContent(content_file):
    body=""
    if os.path.isfile(content_file):
       	body = open(content_file).read()
    return body
def send_mail(to_list,sub,content):
    '''
    to_list:发给谁
    sub:主题
    content:内容
    send_mail("xxxx@starcor.cn","sub","content")
    '''
    msg = MIMEMultipart()
#    att = MIMEText(open('/home/starcor/nn_shell/check_back/log/report.xls', 'rb').read(), 'base64', 'uft-8')
 #   att["Content-Type"] = 'application/octet-stream'
  #  att["Content-Disposition"] = 'attachment; filename="report.xls"'#>这里的filename可以任意写，写什么名字，邮件中显示什么名字
  # msg.attach(att)
    me=mail_user
    htm = MIMEText(content,_subtype='html',_charset='utf-8')
    msg.attach(htm)
    msg['Subject'] = sub.decode('utf-8')
    msg['From'] = me
    msg['To'] = ";".join(to_list)
    try:
        s = smtplib.SMTP_SSL()
        s.connect("smtp.exmail.qq.com",465)
        s.login(mail_user,mail_pass)
        s.sendmail(me, to_list, msg.as_string().decode('utf-8'))
        s.close()
        return True
    except Exception, e:
        print str(e)
        return False
if __name__ == '__main__':
    args = sys.argv
    if len(args)<3:
	print "Invail Arg!\n usage:python %s sub content"%(args[0])
	sys.exit(1)
    Sub=args[1]
    result=args[2]
    Content=getContent(result)
    if send_mail(mailto_list,Sub,Content):
        print "Send Mail Success"
    else:
        print "Send Mail Faild"
