#!/bin/bash

#Function "check Url"
#Auther "ruihua.wang"
#date "2015-10-26"

export PATH="/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin:/usr/local/mysql/bin"
dir=$(cd `dirname -- "$0"` && pwd)

#项目名称
project_name="MGTV"
#项目负责人
responsible_person="王瑞华"

#记录错误内容目录
logdir="$dir/error_log"
#接口返回内容目录
content_dir="$dir/content"
#时间
date="`date +%Y-%m-%d-%H%M`"
#正常返回状态码
code="200"
CURL="$(which curl)"

echo "Start Check" >> ${dir}/check.log
echo "${date}" >> $dir/check.log

#############################################
function check_dir(){
	if [ ! -d ${logdir} ];then
		mkdir ${logdir}
	fi
	
	if [ ! -d ${content_dir} ];then
		mkdir ${content_dir}
	fi
}
##########################################  检测 URL ################################################
function check_url(){
	cat $dir/list.txt |grep -vE "^#|^$"|while read function IP_Type content_num url
	do
		for IP in `cat ${dir}/${IP_Type} |grep -vE "^#|^$"`
		do
			#http_code="`$CURL  -x $IP:80 -s -m 10 --connect-timeout 10 --retry-delay 1 --retry 3   -w %{http_code} $url  -o $content_dir/${IP}-${function}`"
			http_code="`$CURL  -x $IP:80 -s -m 10 --connect-timeout 10 --retry 3 --retry-delay 5  -w %{http_code} $url  -o $content_dir/${IP}-${function}`"
			DATE=`date +"%Y-%m-%d %H:%M:%S"`
			if [ -e $content_dir/${IP}-${function} ];then
				num="`cat $content_dir/${IP}-${function} |wc -c`"
			else
				num=0
			fi
	
			case ${http_code} in
				200)
					if [ ${num} -lt ${content_num} ];then 
						i=0
						while (($i<5))
						do
							$CURL  -x $IP:80 -s -m 10 --connect-timeout 10 --retry 3 --retry-delay 5  $url  -o $content_dir/${IP}-${function} >/dev/null 2>&1 
							if [ -e $content_dir/${IP}-${function} ];then
                         					num1="`cat $content_dir/${IP}-${function} |wc -c`"
                        				else
                                				num1=0
                        				fi
							if [ ${num1} -lt ${content_num} ];then 
								sleep 2s
								i=$(($i+1))
							else
								continue 2
							fi
						done
							
						if [ "$function" == "获取播放串" ];then
							CDN=`cat $content_dir/${IP}-${function}|awk -F "\"" '{print $28}'` 
							Play_Url=`cat $content_dir/${IP}-${function}|awk -F "\"" '{print $4}'`
							reason=`cat $content_dir/${IP}-${function}|awk -F "\"" '{print $12}'|awk -F ":" '{print $2}'`
							if [ -z "$Play_Url" ];then
								if [ ! -z "$CDN" ];then
									if [ "$CDN" -eq 1 ];then
										if [ ! -z "$reason" ];then
				 							echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person}  CDN未获取到播串,原因为:$reason">>$logdir/$date-error.txt	
										else
				 							echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person}  CDN未获取到播串,原因未知">>$logdir/$date-error.txt	
										fi
									elif [ "$CDN" -eq 0 ];then
										if [ ! -z "$reason" ];then
				 							echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person}  CDN未获取到播串,原因为:$reason">>$logdir/$date-error.txt	
										else
				 							echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person}  CDN未获取到播串,原因未知">>$logdir/$date-error.txt	
										fi

									fi
								elif [ ! -z "$reason" ];then
				 					echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未获取到播放串,原因为:$reason">>$logdir/$date-error.txt
								else
				 					echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person}  未获取到播串,原因未知">>$logdir/$date-error.txt	
								fi
							else
				 				echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未知原因">>$logdir/$date-error.txt
								
							fi
						elif [ "$function" == "获取微信二维码" ];then
							Qr_Url=`cat $content_dir/${IP}-${function}|awk -F "\"" '{print $12}'`
							wx_reason=`cat $content_dir/${IP}-${function}|awk -F "\"" '{print $6}'`
							if [ -z "$Qr_Url" ];then
								if [ ! -z "$wx_reason" ];then	
				 					echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未获取到微信二维码,原因为:'$wx_reason'">>$logdir/$date-error.txt	
								else
				 					echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未获取到微信二维码,原因未知">>$logdir/$date-error.txt	
								fi
									
							elif [ ! -z "$wx_reason" ];then
				 				echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未获取到微信二维码,原因为:'$wx_reason' ">>$logdir/$date-error.txt	
							
							else
				 				echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未获取到微信二维码,原因未知">>$logdir/$date-error.txt	
							
							fi

						else 
				 			echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num1} ${url} ${DATE} ${responsible_person} 未知原因">>$logdir/$date-error.txt	
								
						fi
					fi	
				;;
				000)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 连接超时">>$logdir/$date-error.txt	
				;;
				404)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 未找到内容">>$logdir/$date-error.txt	
				;;
				502)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 无效响应">>$logdir/$date-error.txt	
				;;	
				500)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 服务器内部错误">>$logdir/$date-error.txt	
				;;	
				400)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 参数错误">>$logdir/$date-error.txt	
				;;
				302)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 临时跳转">>$logdir/$date-error.txt	
				;;
				403)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 服务器拒绝请求">>$logdir/$date-error.txt	
				;;

				*)
			 		echo "${project_name} Failue ${function} ${IP} ${http_code} ${content_num} ${num} ${url} ${DATE} ${responsible_person} 未知错误">>$logdir/$date-error.txt	
				;;	
			esac
				
		done
	done

}
### ##################################           报警 发邮件                ###################################################
function send_mail(){

		if [ -e $logdir/$date-error.txt ];then
			echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">" >>$logdir/$date-error.html
			echo "<table border=1 cellspacing=0 cellpadding=0><tr><td><strong>Check Status</strong></td><td><strong>接口功能</strong></td><td><strong>IP</strong></td><td><strong>状态码</strong></td><td><strong>设定的字节数</strong></td><td><strong>实际返回字节数</strong></td><td><strong>错误原因</strong></td><td><strong>URL</strong></td></tr>">>$logdir/$date-error.html
			cat $logdir/$date-error.txt | while read project check_result interface_func ip status expect_bytes return_bytes url time hour responsible_person reason
			do
				 echo "<tr><td><font color='#FF0000'>${check_result}</font></td><td>${interface_func}</td><td>${ip}</td><td><font color='#FF0000'>${status}</font></td><td>${expect_bytes}</td><td>${return_bytes}</td><td><font color='#FF0000'>${reason}</font></td><td>${url}</td></tr>" >> $logdir/$date-error.html
			done
			echo "</table>" >> $logdir/$date-error.html
				/usr/bin/python $dir/nn_SendMail.py "${project_name} CHECK URL" "$logdir/$date-error.html" >>${dir}/check.log
		fi
}

function report_urlalert(){
	if [ -e $logdir/$date-error.txt ];then
		 cat $logdir/$date-error.txt | while read project check_result interface_func ip status expect_bytes return_bytes url time hour responsible_person reason
                 do
		 	Date_Time="$time $hour" 
			 ./add_url_alert.sh $project $ip $interface_func $status $expect_bytes $return_bytes $url "$Date_Time" $responsible_person >> ${dir}/check.log

                 done
			
	fi

	

}

function clear(){
	if [ -d $content_dir ];then
		rm -rf $content_dir/*
	else
		exit 1
	fi

}
#####################################################
check_dir
check_url
send_mail
report_urlalert
clear
