#!/bin/bash
# add url alert script
# author: congqing.li
# Usage:
#   ./add_url_alert.sh <project> <ip> <interface_func> <status> <expect_bytes> <return_bytes> <url> <date> <responsible_person>
#       <project>           项目名
#       <ip>                ip地址
#       <interface_func>    接口功能
#       <status>            返回状态码
#       <expect_bytes>      期望返回字节数 example: 200
#       <return_bytes>      实际返回字节数 example: 100
#       <url>               接口url地址
#       <date>              发生时间，格式：2016-02-22 14:37:23
#       <responsible_person>负责人

# nn_opms 主机地址
host='182.138.101.48:54880'

# 登录nn_opms后cookie文件
cookie_file=/tmp/nn_opms_sh.cookies

# 登录nn_opms的接口
login_api="/login"

# 上报url报警的接口
report_url_alert_api="/zabbix/url/alert"

# check variable NN_OPMS_USER NN_OPMS_PASS
#if [ ! $NN_OPMS_USER ]
#then
#    echo "No variable NN_OPMS_USER use to login nn_opms, please export NN_OPMS_USER='<username>'"
#    exit 1
#fi
#if [ ! $NN_OPMS_PASS ]
#then
#    echo "No variable NN_OPMS_PASS use to login nn_opms, please export NN_OPMS_PASS='<username>'"
#    exit 1
#fi
# 用户名密码是环境变量，你可以选择设置环境变量，或直接在此处修改
login_user="ruihua.wang"
login_pass="123456"
headers='Content-Type:application/json --header Accept:application/json'

#####################################################
# 检查接口返回是否正确
# 使用： check_err <test_func_name> <test_response>
#####################################################
function check_err() {
    if [ `echo $2 | grep '"status": "OK"' | wc -l` -eq 1 ]
    then
        echo -e "\033[32;42;1m Run $1 success: $2.\033[0m"
    else
        echo -e "\033[31;42;1m Run $1 failure: $2.\033[0m"
        exit 1
    fi
}

#####################################################
# 登录
#####################################################
login() {
    response=`curl  -XPOST -c ${cookie_file} ${host}${login_api} --header "Accept:application/json" --data "username=${login_user}&password=${login_pass}"`
    check_err login "$response"
}

#####################################################
# 上报url报警
#####################################################
report_url_alert() {
    response=`curl -s -XPOST -b ${cookie_file} ${host}${report_url_alert_api} --header $headers -d "
    {
        \"project\": \"$1\",
        \"ip\": \"$2\",
        \"interface_func\": \"$3\",
        \"status\": $4,
        \"expect_bytes\": $5,
        \"return_bytes\": $6,
        \"url\": \"$7\",
        \"date\": \"$8\",
        \"responsible_person\": \"$9\"
    }"`
    check_err "report_url_alert" "${response}"
}

# 检查是否有登录cookies文件
if [ ! -f ${cookie_file} ]
then
    login
fi

if [ ! $# -eq 9 ]
then
    echo "Usage: $0 <project> <ip> <interface_func> <status> <expect_bytes> <return_bytes> <url> <date> <responsible_person>"
    exit 1
fi

report_url_alert "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9"
